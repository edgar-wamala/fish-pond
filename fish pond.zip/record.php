<?php

  $servername = "localhost";
  $username = "hamfarmug_ham";
  $password = "Hjustinee2";
  $dbname = "hamfarmug_goat";
  


$con  = mysqli_connect( $servername, $username, $password, $dbname);
 if (!$con) {
     # code...
    echo "Problem in database connection! Contact administrator!" . mysqli_error();
 }else{
         $sql ="SELECT * FROM sensor";
         $result = mysqli_query($con,$sql);
         $chart_data="";
         while ($row = mysqli_fetch_array($result)) { 
 
            $productname[]  = $row['time']  ;
            $sales[] = $row['turbidity'];
            $ph[] = $row['ph'];
            $temp[] = $row['temperature'];
            $oxy[] = $row['oxygen'];
            
            //''''''''''
            
            
            
          //''''''''''''  
        }
 
 
 }
 
 
?>