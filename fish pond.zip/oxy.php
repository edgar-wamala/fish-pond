
<?php

$page = $_SERVER['PHP_SELF'];
 $sec = "3";
 header("Refresh: $sec; url=$page");
 ?>
 
<?php require_once 'record.php'; ?>
<!DOCTYPE html>
<html lang="en"> 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Graph</title> 


        <style>
body {
  font-family: "Lato";
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(5, 4, 73);
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #f1e8e8;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


.back { background-color: skyblue;}

button {

  background-color: skyblue;
border:none;
padding: 0.7em;



}
a{ text-decoration: none;}

.fi{ color:blueviolet}


</style>




    </head>
    <body>

    <div class ="back">
        <center> 
            <button><a href ="index.html" style="color:white"><h3>Home</h3></a></button>
         <button><a href ="data.php" style="color:white"><h3>Sensor data</h3></a></button>
       
       <button><a href ="analysis.html" style="color:white"><h3>Analysis </h3></a></button>
     
     
     
     <button><a href ="#" style="color:white"><h3>Register</h3></a></button>
     <button><a href ="#" style="color:white"><h3>login</h3></a></button>
     
     </center>
     </div>


<div class="sidenav">
  <a href="analysis.html">Analysis</a>
  <a href="oxy.php">Oxygen</a>
  <a href="temp.php">Temperature</a>
  <a href="tub.php">Turbidity</a>
  <a href="ph.php">PH</a>
</div>


<div class="main">
  <center>
        <div style="width:60%;hieght:20%;text-align:center">
            <h2 class="page-header" >Oxygen variations with Temperature </h2>
            <p style="align:center;"><canvas  id="chartjs_bar"></canvas></p>
        </div>   
  </center> 

</div>

    </body>
  <script src="js/jquery.js"></script>
  <script src="js/Chart.min.js"></script>
<script type="text/javascript">
      var ctx = document.getElementById("chartjs_bar").getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels:<?php echo json_encode($temp); ?>,
                        datasets: [{
                            label: "Temperature",
                            fill: false,
              lineTension: 0.1,
              backgroundColor: "rgba(59, 89, 152, 0.75)",
              borderColor: "rgba(29, 202, 255, 1)",
              pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
              pointHoverBorderColor: "rgba(59, 89, 152, 1)",
                            data:<?php echo json_encode($oxy); ?>,
                        }]
                    },
                    options: {
                           legend: {
                        display: true,
                        position: 'bottom',
 
                        labels: {
                            
                            fontFamily: 'Circular Std Book',
                            fontSize: 14,
                        }
                    },
 
 
                }
                });
    </script>
</html>