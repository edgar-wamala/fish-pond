<?php
//connection to database

//$temperature=$_GET['temperature']

include("conn.php");

date_default_timezone_set("Africa/Nairobi");
$time = date("H:i:s"); //adds time stamp
$tempF = $_POST["temp"];
$humid = $_POST["tub"];
$ph = $_POST["ph"];
//$oxy = $_POST["oxy"];


//$data = $time."  -Temperature:  ".$tempF."  -Humidity  ".$humid;

//Ensure query is true
$do = (200/$tempF);
$oxy = round($do, 0);
echo $oxy;

if($tempF >30){
    $temp = "INSERT INTO notify (temperature,  time) VALUES ('$tempF','$time' )";
    $conn->query($temp);
}

if($humid >25){
    $tub = "INSERT INTO notify (turbidity,  time) VALUES ('$humid','$time' )";
    $conn->query($tub);
}

if($ph >8.5){
    $hph = "INSERT INTO notify (hph,  time) VALUES ('$ph','$time' )";
    $conn->query($hph);
}
 
if($ph <6.5){
    $lph = "INSERT INTO notify (lph,  time) VALUES ('$ph','$time' )";
    $conn->query($lph);
}

$sql = "INSERT INTO sensor (temperature, turbidity, ph, oxygen, time) VALUES ('$tempF','$humid','$ph', '$oxy','$time' )"; //Query to input POST data into tempsen database
//Ensure query is true
if ($conn->query($sql) == TRUE){
echo $tempF."worked successfull";
}
else{
    die('Failed query:' .$sql); //Kills the connection to the database if the query fails
    }




?>