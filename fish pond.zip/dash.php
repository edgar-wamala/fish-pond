<?php
include 'conn.php';
	
?>
<html>
<head>
<title>
POS
</title>
    <link rel="shortcut icon" href="main/images/pos.jpg">

  <link href="main/css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="main/css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="main/css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<br/>
<center><h1>fish pond</h2></center>

<body class ="page1">
    <div class="container-fluid">
      <div class="row-fluid">
		<div class="span4">
		</div>
	
</div>




	
        
<div id="login" class="login">
<?php


?>
   
<form action="login.php" method="post">

			<font style=" font:bold 44px 'Aleo'; color:#fff;"><center>Login Panel  </center></font>
		<br>

		
<div class="input-prepend">
		<span style="height:30px; width:25px;" ><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="username" Placeholder="Username" required/><br><br>
</div>
<div class="input-prepend">
	<span style="height:30px; width:25px;"><i class="icon-lock icon-2x"></i></span><input type="password" style="height:40px;" name="password" Placeholder="Password" required/><br>
		</div>
		<br/><br/><br/>
		<div class="qwe">
		 <button class="btn btn-large btn-primary btn-block pull-right" href="dashboard.html" type="submit"><i class="icon-signin icon-large"></i> LOGIN</button>
</div>
		 </form>
</div>
</div>
</div> 
</div>
</body>
</html>