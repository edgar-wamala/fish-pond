<?php

$page = $_SERVER['PHP_SELF'];
 $sec = "2";
 header("Refresh: $sec; url=$page");
 ?>


<!DOCTYPE html>
<html>
<head>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
body {
  font-family: "Lato";
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(5, 4, 73);
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #f1e8e8;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


.back { background-color: skyblue;}

button {

  background-color: skyblue;
border:none;
padding: 0.7em;



}
a{ text-decoration: none;}

.fi{ color:blueviolet}


</style>



<style>
table {
  border-collapse: collapse;
  width: 80%;
  font-size: 1.2em;
}

th, td {
  text-align: left;
  padding: 1%;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: skyblue;
  color: white;
}

</style>




<style>
  

  .icon-button {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 50px;
  height: 50px;
  color: #333333;
  background: #dddddd;
  border: none;
  outline: none;
  border-radius: 50%;
}

.icon-button:hover {
  cursor: pointer;
}

.icon-button:active {
  background: #cccccc;
}

.icon-button__badge {
  position: absolute;
  top: -10px;
  right: -10px;
  width: 25px;
  height: 25px;
  background: red;
  color: #ffffff;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
}


  
</style>




</head>
<body style ="background-color:rgb(255, 251, 243)">
<?php

 include("conn.php");
 $notify_temperature =" ";
 $not2 = "SELECT * FROM notify";
$result2 = $conn->query($not2);

if ($result2->num_rows > 0) {
 
  
  while($row = $result2->fetch_assoc()) {

  
    if($row["temperature"] || $row["Turbidity"] || $row["hph"] || $row["lph"] != NULL  ){
      $notify_temperature = $row["temperature"];

  }
}
}
 ?>

<div class ="back">
   <center> 

    <button><a href ="index.html" style="color:white"><h3>Home</h3></a></button>
    
    <button><a href ="data.php" style="color:white"><h3>Sensor data</h3></a></button>
  
  <button><a href ="analysis.html" style="color:white"><h3>Analysis </h3></a></button>

        <button><a href ="#" style="color:white"><h3>Register</h3></a></button>
      <button><a href ="#" style="color:white"><h3>login</h3></a></button>
    

    
</center>
</div>

     <br/><br/>

     
      <button type="button" class="icon-button">
      <span class="material-icons">notifications</span>
      <?php
     if($notify_temperature != " "  ){ ?><a href ="notify.php" ><span class="icon-button__badge">!</span></a> <?php } ?>
     </button>
   
<div class ="main">

<?php

$sql = "SELECT  * FROM sensor";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo"<center>";

 
  echo "<table ><tr><th>temperature</th><th>PH</th>
        <th>turbidity</th> <th>oxygen</th> <th>Date</th> 
  </tr>";

  

  // output data of each row
  
  
  while($row = $result->fetch_assoc()) {

 
    

    echo "<tr><td>".$row["temperature"]."</a>"."</td><td>".$row["ph"]."</td><td>".$row["turbidity"]."</td><td>".$row["oxygen"]."</td><td>".$row["time"]."</td>"    ."</tr>";
    
  }
  echo "</table>";
 echo" </center>";
} else {
  echo "0 results";
}
$conn->close();
?>

</div>

</body>
</html>