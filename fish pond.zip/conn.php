 <?php
 
 // Converts it into a PHP object

  $servername = "localhost";
  $username = "hamfarmug_ham";
  $password = "Hjustinee2";
  $dbname = "hamfarmug_goat";
  
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    //$conn = mysqli_connect('localhost', 'hamfarmug_goat', 'Hjustinee2', 'hamfarmug_ham');
  
  // Check connection
    if (!$conn) {
    echo"connection failed";
     }

  

?> 