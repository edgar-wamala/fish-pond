<?php
include("conn.php");
	//Start session
	session_start();
	
	//Array to store validation errors
	//$errmsg_arr = array();
	
	//Validation error flag
//	$errflag = false;
	
	//Connect to mysql server
	
	
	//Select database
	// $db = mysql_select_db('sales', $link);
	// if(!$db) {
	// 	die("Unable to select database");
	// }
	
	// //Function to sanitize values received from the form. Prevents SQL injection
	// function clean($str) {
	// 	$str = @trim($str);
	// 	if(get_magic_quotes_gpc()) {
	// 		$str = stripslashes($str);
	// 	}
	// 	return mysqli_real_escape_string($str);
	// }
	
	// //Sanitize the POST values
	// $login = clean($_POST['username']);
	// $password = clean($_POST['password']);
	$login = $_POST['username'];
	$password = $_POST['password'];
	
	// //Input Validations
	// if($login == '') {
	// 	$errmsg_arr[] = 'Username missing';
	// 	$errflag = true;
	// }
	// if($password == '') {
	// 	$errmsg_arr[] = 'Password missing';
	// 	$errflag = true;
	// }
	
	//If there are input validations, redirect back to the login form
	
	//Create query
	$qry="SELECT * FROM users WHERE username='$login' AND password='$password'";
	$result=mysqli_query($conn,$qry);
	
	//Check whether the query was successful or not
	if($result) {
		if(mysqli_num_rows($result) > 0) {
			
			header("location: index.php");
			
		}else {
			//Login failed
                        echo 'Wrong login details';
			
		}
	}else {
		die("Query failed");
	}
?>