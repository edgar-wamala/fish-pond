<!DOCTYPE html>
<html>
<head>


<style>

body{ background-color:rgb(90, 88, 88);}

.back { background-color: ;}

button {

  background-color: pink;
border:none;
padding: 0.2em;



}
a{ text-decoration: none;}

.fi{ color:blueviolet}
</style>




<style>
table {
  border-collapse: collapse;
  width: 80%;
  font-size: 1.2em;
}

th, td {
  text-align: left;
  padding: 1%;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: skyblue;
  color: white;
}

a{font-size:1.2em;
align-items: center;}

</style>
</head>
<body style ="background-color:rgb(255, 251, 243)">


<div class ="back">
   <center> 

    <button><a href ="index.html" style="color:white"><h3>Home</h3></a></button>
    
    <button><a href ="data.php" style="color:white"><h3>Sensor data</h3></a></button>
  
  <button><a href ="analysis.html" style="color:white"><h3>Analysis </h3></a></button>

<button><a href ="not.php" style="color:white"><h3>Notification and recommedation<h3></a></button>

<button><a href ="#" style="color:white"><h3>Register</h3></a></button>
<button><a href ="#" style="color:white"><h3>login</h3></a></button>

<br/><br/><br/>

<?php

 include("conn.php");


$sql = "SELECT  * FROM sensor";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo"<center>";

 
  echo "<table ><tr><th>temperature</th><th>PH</th>
        <th>turbidity</th> <th>oxygen</th> <th>Date</th> 
  </tr>";

  

  // output data of each row
  
  
  while($row = $result->fetch_assoc()) {

 
    

    echo "<tr><td>".$row["temperature"]."</a>"."</td><td>".$row["ph"]."</td><td>".$row["turbidity"]."</td><td>".$row["oxygen"]."</td><td>".$row["time"]."</td>"    ."</tr>";
    
  }
  echo "</table>";
 echo" </center>";
} else {
  echo "0 results";
}
$conn->close();
?>
</body>
</html>