<?php require_once 'record.php'; ?>
<!DOCTYPE html>
<html lang="en"> 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Graph</title> 


        <style>
body {
  font-family: "Lato";
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(5, 4, 73);
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #f1e8e8;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


.back { background-color: skyblue;}

button {

  background-color: skyblue;
border:none;
padding: 0.7em;



}
a{ text-decoration: none;}

.fi{ color:blueviolet}


</style>



<style>
table {
  border-collapse: collapse;
  width: 80%;
  font-size: 1.2em;
}

th, td {
  text-align: left;
  padding: 1%;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: skyblue;
  color: white;
}




</style>


    </head>
    <body>

    <div class ="back">
        <center> 
            <button><a href ="index.html" style="color:white"><h3>Home</h3></a></button>
         <button><a href ="registerRefugee.html" style="color:white"><h3>Sensor data</h3></a></button>
       
       <button><a href ="analysis.html" style="color:white"><h3>Analysis </h3></a></button>
     
     <button><a href ="received.html" style="color:white"><h3>Notification and recommedation<h3></a></button>
     
     <button><a href ="registerRefugee.html" style="color:white"><h3>Register</h3></a></button>
     <button><a href ="registerRefugee.html" style="color:white"><h3>login</h3></a></button>
     
     </center>
     </div>


<br/>


<div class="main">

  <center>

  <table border =1>
  <tr><th>Notification</th><th>Recommendation</th>
        
        </tr>
 <?php

include("conn.php");

$temperature_not = " ";
$hph_not = " ";
$lph_not = " ";
$turbidity_not = " ";

$sql = "SELECT  * FROM notify";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
 

 // output data of each row
 
 while($row = $result->fetch_assoc()) {



   if($row["temperature"] !=NULL){

    $temperature_not =$row["temperature"];
   }

   
   if($row["turbidity"] !=NULL){

    $turbidity_not =$row["turbidity"];
   }
   

   
   if($row["hph"] !=NULL){

    $hph_not =$row["hph"];
   }

   if($row["lph"] !=NULL){

    $lph_not =$row["lph"];
   }


  }



}


if($temperature_not !=" "){
  ?> 

  <tr>
    <td> temperatures are very high</td> 
 <td> precautions need to be taken to reduce on the temperature</td>
  
</tr>


  <?php } ?>


  <?php
  if($turbidity_not !=" "){
  ?> 

  <tr>
    <td> Turbidity is not normal</td> 
 <td> The current water needs to be changed</td>
  
</tr>
  <?php } ?>


  <?php
  if($hph_not !=" "){
  ?> 

 <tr>
    <td> PH is too low</td> 
 <td> Add acidic solution to neutralize it to normal</td>

</tr>
  <?php } ?>

  <?php
  if($lph_not !=" "){
  ?> 

 <tr>
    <td> PH is too acidic</td> 
 <td> Add alkalin solution to neutralize it to normal</td>
  
</tr>
  <?php } ?>




  <?php

$conn->close();


?> 

</table>
  </center> 
</div> 
    </body>
  
    </script>
</html>